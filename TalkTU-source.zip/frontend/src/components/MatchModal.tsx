import matchLogo from '../../assets/images/match.png';
import { useEffect, useRef, useState } from 'react';
import { Animated } from 'react-native';
import { supabase } from '@/lib/supabase';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { sendMessage } from '@/features/chat/services/chatService';
import { Ionicons } from '@expo/vector-icons';

type MatchModalProps = {
  visible: boolean;
  displayName: string;
  candidatePhotoPath?: string | null;
  matchId?: string | null;
  onContinue: () => void;
};

export default function MatchModal({
  visible,
  displayName,
  candidatePhotoPath,
  matchId,
  onContinue,
}: MatchModalProps) {
  const [message, setMessage] = useState('');
  const matchAnim = useRef(new Animated.Value(0)).current;

  const leftCardAnim = useRef(new Animated.Value(0)).current;
  const rightCardAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!visible) return;

    leftCardAnim.setValue(0);
    rightCardAnim.setValue(0);
    matchAnim.setValue(0);

    Animated.sequence([
      // การ์ดสองฝั่งวิ่งเข้าหากัน
      Animated.parallel([
        Animated.spring(leftCardAnim, {
          toValue: 1,
          speed: 7,
          bounciness: 8,
          useNativeDriver: true,
        }),
        Animated.spring(rightCardAnim, {
          toValue: 1,
          speed: 7,
          bounciness: 8,
          useNativeDriver: true,
        }),
      ]),

      // โลโก้ MATCH เด้งขึ้นมา
      Animated.sequence([
        Animated.timing(matchAnim, {
          toValue: 0.8,
          duration: 250,
          useNativeDriver: true,
        }),
        Animated.spring(matchAnim, {
          toValue: 1,
          speed: 12,
          bounciness: 22,
          useNativeDriver: true,
        }),
      ]),
    ]).start();
  }, [visible, leftCardAnim, rightCardAnim, matchAnim]);

  const [sending, setSending] = useState(false);
  const [sendSucceeded, setSendSucceeded] = useState(false);

  useEffect(() => {
    if (visible) {
      setMessage('');
      setSending(false);
      setSendSucceeded(false);
      setToastMessage('');
    }
  }, [visible, matchId]);

  const [toastMessage, setToastMessage] = useState('');

  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const successTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = (text: string) => {
    if (toastTimer.current) {
      clearTimeout(toastTimer.current);
    }

    setToastMessage(text);

    toastTimer.current = setTimeout(() => {
      setToastMessage('');
      toastTimer.current = null;
    }, 1500);
  };

  useEffect(() => {
    if (!visible) {
      if (toastTimer.current) {
        clearTimeout(toastTimer.current);
        toastTimer.current = null;
      }

      if (successTimer.current) {
        clearTimeout(successTimer.current);
        successTimer.current = null;
      }
    }

    return () => {
      if (toastTimer.current) {
        clearTimeout(toastTimer.current);
        toastTimer.current = null;
      }

      if (successTimer.current) {
        clearTimeout(successTimer.current);
        successTimer.current = null;
      }
    };
  }, [visible, matchId]);

  const [candidateImageUrl, setCandidateImageUrl] =
    useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    setCandidateImageUrl(null);

    if (!visible || !candidatePhotoPath) {
      return;
    }

    async function loadPhoto() {
      try {
        const path = candidatePhotoPath!;

        if (path.startsWith('https://') || path.startsWith('http://')) {
          if (!cancelled) setCandidateImageUrl(path);
          return;
        }

        const { data, error } = await supabase.storage
          .from('profile-photos')
          .createSignedUrl(path, 60 * 60);

        if (error) throw error;

        if (!cancelled) {
          setCandidateImageUrl(data.signedUrl);
        }
      } catch (error) {
        console.error('Match photo error:', error);
      }
    }

    loadPhoto();

    return () => {
      cancelled = true;
    };
  }, [visible, candidatePhotoPath]);

  const [myImageUrl, setMyImageUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    setMyImageUrl(null);

    if (!visible) {
      return;
    }

    async function loadMyPhoto() {
      try {
        const { data: authData, error: authError } =
          await supabase.auth.getUser();

        if (authError) throw authError;

        const userId = authData.user?.id;
        if (!userId) return;

        const { data: photo, error: photoError } = await supabase
          .from('profile_photos')
          .select('storage_path')
          .eq('user_id', userId)
          .order('position', { ascending: true })
          .limit(1)
          .maybeSingle();

        if (photoError) throw photoError;
        if (!photo?.storage_path) return;

        const { data, error } = await supabase.storage
          .from('profile-photos')
          .createSignedUrl(photo.storage_path, 60 * 60);

        if (error) throw error;

        if (!cancelled) {
          setMyImageUrl(data.signedUrl);
        }
      } catch (error) {
        console.error('My match photo error:', error);
      }
    }

    loadMyPhoto();

    return () => {
      cancelled = true;
    };
  }, [visible]);

  const handleSendMessage = async () => {
    const content = message.trim();

    if (!content || sending || sendSucceeded) return;

    if (!matchId) {
      showToast('Match not found.');
      return;
    }

    setSending(true);

    try {
      const result = await sendMessage(matchId, content);

      if (result.error) {
        throw result.error;
      }

      setSendSucceeded(true);
      setMessage('');
      setToastMessage('Sent! See you in Chat 💬');

      // Show the success toast briefly before returning.
      successTimer.current = setTimeout(() => {
        successTimer.current = null;
        setToastMessage('');
        onContinue();
      }, 1500);
    } catch (error) {
      console.error('Match message error:', error);
      showToast('Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent={false}
      animationType="fade"
      onRequestClose={onContinue}
      statusBarTranslucent
    >
      <LinearGradient
        colors={['#FF7885', '#FF9A83', '#FFE6B8']}
        locations={[0, 0.5, 1]}
        style={styles.container}
      >
        <KeyboardAvoidingView
          style={styles.keyboardAvoidingView}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={0}
        >
          <TouchableOpacity
            style={styles.closeButton}
            onPress={onContinue}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={28} color="#FFFFFF" />
          </TouchableOpacity>

          <View style={styles.centerArea}>
            <View style={styles.photoArea}>
              {/* Left Card */}
              <Animated.View
                style={[
                  styles.photoCard,
                  styles.leftPhoto,
                  {
                    transform: [
                      {
                        translateX: leftCardAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [-280, 0],
                        }),
                      },
                      { rotate: '-13deg' },
                    ],
                  },
                ]}
              >
                {candidateImageUrl ? (
                  <Image
                    source={{ uri: candidateImageUrl }}
                    style={styles.photo}
                    resizeMode="cover"
                  />
                ) : candidatePhotoPath ? (
                  <ActivityIndicator color="#FF7885" />
                ) : (
                  <Text style={styles.photoPlaceholder}>♡</Text>
                )}
              </Animated.View>

              {/* Right Card */}
              <Animated.View
                style={[
                  styles.photoCard,
                  styles.rightPhoto,
                  {
                    transform: [
                      {
                        translateX: rightCardAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [280, 0],
                        }),
                      },
                      { rotate: '13deg' },
                    ],
                  },
                ]}
              >
                {myImageUrl ? (
                  <Image
                    source={{ uri: myImageUrl }}
                    style={styles.photo}
                    resizeMode="cover"
                  />
                ) : (
                  <Text style={styles.photoPlaceholder}>♡</Text>
                )}
              </Animated.View>

              {/* MATCH Logo */}
              <Animated.Image
                source={matchLogo}
                resizeMode="contain"
                style={[
                  styles.matchLogo,
                  {
                    opacity: matchAnim,
                    transform: [
                      {
                        scale: matchAnim.interpolate({
                          inputRange: [0, 0.65, 0.85, 1],
                          outputRange: [0.1, 2.5, 0.8, 1],
                        }),
                      },
                    ],
                  },
                ]}
              />
            </View>
          </View>

          {toastMessage !== '' && (
            <View style={styles.toastContainer}>
              <Text style={styles.toastText}>{toastMessage}</Text>
            </View>
          )}

          <View style={styles.bottomArea}>
            <View style={styles.messageRow}>
              <TextInput
                placeholder={`Say something to ${displayName}`}
                placeholderTextColor="#999999"
                style={[
                  styles.messageInput,
                  Platform.OS === 'web' && ({ outline: 'none' } as any),
                ]}
                value={message}
                onChangeText={setMessage}
                editable={!sending && !sendSucceeded}
                maxLength={5000}
                returnKeyType="send"
                onSubmitEditing={handleSendMessage}
              />

              {message.trim().length > 0 && (
                <TouchableOpacity
                  style={styles.sendButton}
                  onPress={handleSendMessage}
                  disabled={sending || sendSucceeded}
                  activeOpacity={0.7}
                >
                  {sending ? (
                    <ActivityIndicator color="#FF7885" size="small" />
                  ) : (
                    <Ionicons name="arrow-up" size={20} color="#FF7885" />
                  )}
                </TouchableOpacity>
              )}
            </View>
          </View>
        </KeyboardAvoidingView>
      </LinearGradient>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 28,
    paddingTop: 80,
    paddingBottom: 65,
  },

  keyboardAvoidingView: {
    flex: 1,
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  centerArea: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },

  photoArea: {
    width: '100%',
    height: 370,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },

  photoCard: {
    position: 'absolute',
    width: 175,
    height: 225,
    borderWidth: 5,
    borderColor: '#FFD98A',
    borderRadius: 24,
    backgroundColor: '#FFE0D3',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },

  leftPhoto: {
    top: 15,
    left: '5%',
  },

  rightPhoto: {
    bottom: 10,
    right: '5%',
  },

  photoPlaceholder: {
    fontSize: 90,
    color: '#FFFFFF',
  },

  matchLogo: {
    position: 'absolute',
    zIndex: 10,
    width: 340,
    height: 240,
    alignSelf: 'center',
    top: '35%',
  },

  bottomArea: {
    width: '100%',
    gap: 16,
  },

  messageInput: {
    flex: 1,
    height: 54,
    paddingHorizontal: 22,
    fontSize: 14,
    color: '#333333',
    borderWidth: 0,
    outlineWidth: 0,
  },

  messageRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 28,
    paddingRight: 12,
    borderWidth: 0,
  },

  photo: {
    width: '100%',
    height: '100%',
  },

  toastContainer: {
    position: 'absolute',
    bottom: 165,
    alignSelf: 'center',
    backgroundColor: 'rgba(40, 40, 40, 0.9)',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 24,
    zIndex: 20,
  },

  toastText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
  },

  sendButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },

  sendIcon: {
    fontSize: 23,
    color: '#FF7885',
  },

  closeButton: {
    position: 'absolute',
    top: 50,
    left: 24,
    zIndex: 20,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
